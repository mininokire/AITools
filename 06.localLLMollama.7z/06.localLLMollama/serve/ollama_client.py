import requests
import base64
from PIL import Image
from io import BytesIO
import json  # 添加标准库 json

class OllamaClient:
    def __init__(self, base_url="http://127.0.0.1:11434", timeout=30):
        self.base_url = base_url
        self.timeout = timeout

    def _post(self, endpoint, payload, stream=False):
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        response = None
        try:
            response = requests.post(url, json=payload, timeout=120, stream=stream)  # 超时时间调整为 120 秒
            response.raise_for_status()
            if stream:
                return response.iter_lines(decode_unicode=True)
            return response.json()
        except requests.exceptions.RequestException as e:
            error_message = f"请求失败：{str(e)} - 响应内容：{response.text if response else '无响应'}"
            raise Exception(error_message)



    def list_models(self):
        """从 /models 获取模型列表"""
        url = f"{self.base_url}/v1/models"
        response = requests.get(url, timeout=self.timeout)
        if response.status_code == 200:
            data = response.json()
            models = {model["id"]: {"name": model["id"], "owned_by": model["owned_by"]} for model in data.get("data", [])}
            return models
        else:
            raise Exception(f"无法获取模型列表：{response.text}")

    def text_generation(self, model, prompt):
        """使用语言模型生成完整文本"""
        payload = {"model": model, "prompt": prompt}
        response_stream = self._post("api/generate", payload, stream=True)
        generated_text = ""
        for line in response_stream:
            if line.strip():
                data = json.loads(line)  # 使用标准库 json
                generated_text += data.get("response", "")
                if data.get("done", False):
                    break
        return generated_text

    def is_model_ready(self, model):
        """检查模型是否已加载"""
        url = f"{self.base_url}/v1/models"
        response = requests.get(url, timeout=120)
        if response.status_code == 200:
            models = response.json().get("data", [])
            return any(m["id"] == model for m in models)
        else:
            raise Exception(f"无法获取模型列表：{response.text}")

    def image_recognition(self, model, image_path):
        """使用视觉模型进行图像识别"""
        if not self.is_model_ready(model):
            raise Exception(f"模型 {model} 未加载，请确认服务状态。")

        url = f"{self.base_url}/api/generate"
        with open(image_path, "rb") as img_file:
            image_data = base64.b64encode(img_file.read()).decode("utf-8")
        payload = {
            "model": model,
            "prompt": f"请描述以下图像内容：{image_data}"
        }
        return self._post("api/generate", payload, stream=True)


    def generate_image(self, model, prompt, size=(512, 512)):
        """使用生成模型生成图片"""
        result = self._post("v1/generate-image", {"model": model, "prompt": prompt, "size": f"{size[0]}x{size[1]}"})
        image_data = result.get("image", "")
        img = Image.open(BytesIO(base64.b64decode(image_data)))
        return img
