from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import os
from io import BytesIO
from ollama_client import OllamaClient
import logging

# 初始化 Flask 和 Ollama 客户端
app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})
ollama = OllamaClient()

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# 设置日志
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

@app.route("/", methods=["GET"])
def home():
    """处理根路径请求"""
    return "<h1>Welcome to the Ollama API</h1><p>Use /models, /generate-text, /recognize-image, or /generate-image endpoints.</p>"

@app.route("/models", methods=["GET"])
def list_models():
    """列出所有可用模型"""
    try:
        models = ollama.list_models()
        return jsonify(models)
    except Exception as e:
        logging.error(f"获取模型列表失败：{str(e)}")
        return jsonify({"error": f"获取模型列表失败：{str(e)}"}), 500

@app.route("/generate-text", methods=["POST"])
def generate_text():
    """生成完整的文本回答"""
    data = request.json
    model = data.get("model")
    prompt = data.get("prompt")
    if not model or not prompt:
        return jsonify({"error": "模型和提示文本不能为空"}), 400
    try:
        response = ollama.text_generation(model, prompt)
        logging.info(f"生成的文本：{response}")
        return jsonify({"result": response})
    except Exception as e:
        logging.error(f"文本生成失败：{str(e)}")
        return jsonify({"error": f"文本生成失败：{str(e)}"}), 500

@app.route("/recognize-image", methods=["POST"])
def recognize_image():
    """图像内容识别"""
    if "file" not in request.files:
        return jsonify({"error": "未上传文件"}), 400
    file = request.files["file"]
    model = request.form.get("model", "llama3.2-vision:latest")
    try:
        file_path = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(file_path)
        result = ollama.image_recognition(model, file_path)
        os.remove(file_path)  # 删除临时文件
        return jsonify({"result": result})
    except Exception as e:
        logging.error(f"图像识别失败：{str(e)}", exc_info=True)  # 记录完整堆栈
        return jsonify({"error": f"图像识别失败：{str(e)}"}), 500



@app.route("/generate-image", methods=["POST"])
def generate_image():
    """生成图片"""
    data = request.json
    model = data.get("model")
    prompt = data.get("prompt")
    size = data.get("size", "512x512")
    if not model or not prompt:
        return jsonify({"error": "模型和提示文本不能为空"}), 400
    try:
        width, height = map(int, size.split("x"))
        img = ollama.generate_image(model, prompt, size=(width, height))
        img_io = BytesIO()
        img.save(img_io, "PNG")
        img_io.seek(0)
        return send_file(img_io, mimetype="image/png")
    except Exception as e:
        logging.error(f"图片生成失败：{str(e)}")
        return jsonify({"error": f"图片生成失败：{str(e)}"}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
